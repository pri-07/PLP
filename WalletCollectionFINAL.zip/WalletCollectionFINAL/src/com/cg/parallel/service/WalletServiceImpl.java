package com.cg.parallel.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.parallel.dao.WalletDAO;
import com.cg.parallel.dao.WalletDAOImpl;
import com.cg.parallel.dto.Customer;
import com.cg.parallel.exception.WalletException;

public class WalletServiceImpl implements WalletService{

	WalletDAO dao;

	public WalletServiceImpl() {
		dao = new WalletDAOImpl();
	}


	//methods
	@Override
	public Customer createAccount(Customer c) {
		return dao.createAccount(c);
	}

	    @Override
	    public double showBalance(String mobileno) {
	        Customer bal = dao.getAccount(mobileno);
	        return bal.getAmount();
	    }

	    @Override
	    public Customer fundTransfer(String sMobNo, String rMobNo,double amount) throws WalletException {
	        Customer sbal = dao.getAccount(sMobNo);
	        Customer rbal = dao.getAccount(rMobNo);
	       
	        if (((sbal.getAmount()) - (amount) >= 0) ) {
	            dao.setAccount(sMobNo, sbal.getAmount() - amount);
	            
	            //ADD
	            dao.setAccount(rMobNo, rbal.getAmount() + amount);
	            return dao.getAccount(sMobNo);
	        }
	        else   //ADD
	        	return null;
	    }
	    


	    @Override
	    public Customer deposit(String mobileNo, double amount)throws WalletException {
	        Customer cDep1 = dao.getAccount(mobileNo);
	        boolean c = dao.setAccount(mobileNo, cDep1.getAmount() + amount);
	        Customer cDep = dao.getAccount(mobileNo);
	        if (!c)
	            throw new WalletException("Unable to deposit");
	        else
	            return cDep;
	    }

	    @Override
	    public Customer withdraw(String mobileNo, double amount)throws WalletException {
	        // TODO Auto-generated method stub
	        boolean c = false;
	        Customer cDep1 = dao.getAccount(mobileNo);
	        if ((cDep1.getAmount() - amount) >= 0)
	            c = dao.setAccount(mobileNo, cDep1.getAmount() - amount);
	        Customer cDep = dao.getAccount(mobileNo);
	        if (!c)
	            throw new WalletException("Unable to withdraw");
	        else
	            return cDep;
	    }
	    
	    public boolean checkAccountExisting(String mobileNo)
	    {
	    	return dao.checkAccountExisting(mobileNo);
	    }
	    
	    
	//validation methods
	@Override
	public boolean validateAll(Customer c) {

		boolean flag = false;
		if (validateCustName(c.getCustomerName()) == true && validatePhoneNumber(c.getMobileNumber()) == true && validateAmount(c.getAmount()) == true)
			flag = true;
			return flag;
	}

	@Override
	public boolean validateCustName(String name) {
		Pattern p = Pattern.compile("[A-Z]{1}[a-z]{1,30}");
		Matcher mat = p.matcher(name);
		boolean b = mat.matches();
		return b;
	}

	@Override
	public boolean validatePhoneNumber(String mobileNo) {
		Pattern pat = Pattern.compile("[6-9]{1}[0-9]{9}");
		Matcher mat = pat.matcher(mobileNo);
		return mat.matches();
	}

	@Override
	public boolean validateAmount(double amt) {
		Pattern pat = Pattern.compile("[1-9]{1}[0-9.]{0,9}");
		Matcher mat = pat.matcher(String.valueOf(amt));
		return mat.matches();
		
//		String r=amt.toString();
//		return (r.matches("\\d[1-9][0-9]{1,7}\\.\\d{0,4}"));
	}

	@Override
	public boolean validateRMobNo(String rMobNo) {
		Pattern pat = Pattern.compile("[6-9]{1}[0-9]{9}");
		Matcher mat = pat.matcher(rMobNo);
		return mat.matches();
	}
	
	
	
	//ADD TEST CASES FOR FUNCTIONS

}
