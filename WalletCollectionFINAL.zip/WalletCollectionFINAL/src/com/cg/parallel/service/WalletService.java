package com.cg.parallel.service;

import com.cg.parallel.dto.Customer;
import com.cg.parallel.exception.WalletException;

public interface WalletService {
	
	//methods
	public Customer createAccount(Customer c);
	public double showBalance(String mobileno);
	public Customer fundTransfer(String sMobNo,String rMobNo, double amount) throws WalletException;
	public Customer deposit(String mobileNo, double amount ) throws WalletException;
	public Customer withdraw(String mobileNo, double amount) throws WalletException;
	public boolean checkAccountExisting(String mobileNo);
//	public boolean AmountPresent(String mobileNo);
	
	
	//validation methods
	public boolean validateCustName(String name);
	public boolean validatePhoneNumber(String mobNo);
	public boolean validateRMobNo(String rMobNo);
	public boolean validateAmount(double amt);
	public boolean validateAll(Customer c);
	
	
}
