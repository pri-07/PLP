package com.cg.parallel.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.cg.parallel.service.WalletServiceImpl;

public class WalletTest {
	
	@Test
	public void ValidateNameTrue(){
		WalletServiceImpl bs = new WalletServiceImpl();
		assertEquals(true, bs.validateCustName("Priya"));
	}
	
	
	@Test
	public void ValidatePhonNumberTrue(){
		WalletServiceImpl bs = new WalletServiceImpl();
		assertEquals(true, bs.validatePhoneNumber("8879542350"));
	}
	
	@Test
	public void ValidatePhoneNumber(){
		WalletServiceImpl bs = new WalletServiceImpl();
		assertEquals(false, bs.validatePhoneNumber("88795423"));
		assertEquals(false, bs.validatePhoneNumber("5423500000"));
		assertEquals(false, bs.validatePhoneNumber("88888"));
		assertEquals(false, bs.validatePhoneNumber("random"));
		assertEquals(false, bs.validatePhoneNumber("@#%"));
	}
	
	@Test 
	public void ValidateNameV2(){
		WalletServiceImpl bs = new WalletServiceImpl();
		assertEquals(false, bs.validateCustName("123Priabc1"));
		assertEquals(false, bs.validateCustName("Priya@1234"));
		assertEquals(false, bs.validateCustName("11846"));
		assertEquals(false, bs.validateCustName("priya"));
	}
	
	@Test
	public void ValidateAmountTrue(){
		WalletServiceImpl bs = new WalletServiceImpl();
		assertEquals(true, bs.validateAmount(500.00));
	}
	
	@Test 
	public void ValidateAmount(){
		WalletServiceImpl bs = new WalletServiceImpl();
		assertEquals(false, bs.validateAmount(0));
		assertEquals(false, bs.validateAmount(-400));
	}
	
	
	

}
