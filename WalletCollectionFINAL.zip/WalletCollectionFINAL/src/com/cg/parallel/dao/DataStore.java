package com.cg.parallel.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.parallel.dto.Customer;

public class DataStore {

	private static Map<String, Customer> mymap;

	public static Map<String, Customer> createCollection() {

		if (mymap == null)
			mymap = new HashMap<String, Customer>();
			mymap.put("8879542350", new Customer("Priya",1000.00));
			mymap.put("9820106188", new Customer("Yogita",500.00));

		return mymap;
	}

}
