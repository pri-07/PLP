package com.cg.parallel.dao;

import java.util.Map;


import com.cg.parallel.dto.Customer;

public class WalletDAOImpl implements WalletDAO {
	
	Map<String, Customer> map;

	
	public WalletDAOImpl() {
		map = DataStore.createCollection();
	}

	   @Override
	    public Customer createAccount(Customer c) {
	        // TODO Auto-generated method stub
	        map.put(c.getMobileNumber(), c);
	        return c;
	    }

	    @Override
	    public Customer getAccount(String mobileno) {
	        // TODO Auto-generated method stub
	        Customer cShow = map.get(mobileno);
			return cShow;
	    }

	    @Override
	    public boolean setAccount(String mobileNo, double amount) {
	        // TODO Auto-generated method stub
	        Customer cSet = map.get(mobileNo);
	        cSet.setAmount(amount);
	        map.put(mobileNo, cSet);
	        return true;
	    }
	    
	    public boolean checkAccountExisting(String mobileNo)
	    {
	    	boolean flag=true;
	    	if(map.get(mobileNo)!=null)
	    		return flag;
	    	else
	    	{
	    		flag=false;
	    		return flag;
	    	}
	    }

}
