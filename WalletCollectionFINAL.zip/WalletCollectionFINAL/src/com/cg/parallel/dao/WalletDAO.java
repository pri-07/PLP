package com.cg.parallel.dao;

import com.cg.parallel.dto.Customer;

public interface WalletDAO {
	
	public Customer createAccount(Customer c);
	boolean setAccount(String mobileNo, double amount);
	Customer getAccount(String mobileno);
	public boolean checkAccountExisting(String mobileNo);
	

}
