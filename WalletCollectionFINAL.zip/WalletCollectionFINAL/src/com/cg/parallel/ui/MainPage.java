package com.cg.parallel.ui;

import java.util.Scanner;

import com.cg.parallel.dto.Customer;
import com.cg.parallel.exception.WalletException;
import com.cg.parallel.service.WalletService;
import com.cg.parallel.service.WalletServiceImpl;

public class MainPage {

	public static void main(String[] args) throws WalletException{

		Scanner sc = new Scanner(System.in);
		WalletService service = new WalletServiceImpl();
		int choice;
		do {
			System.out.println("=+=+=+=+=+=+=+Menu=+=+=+=+=+=+=+");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Fund Transfer");
			System.out.println("4.Deposit");
			System.out.println("5.Withdraw");
			System.out.println("6.Finish");
			System.out.print("Enter your choice:");
			choice = sc.nextInt();

			switch (choice) {
			case 1:
				
				Customer c;
				String name;
				String mobNo=null;
				double iamt=0.0;
				System.out.println("Create Account");
				do
				{
					System.out.print("Enter name: ");
					name = sc.next();
						if (service.validateCustName(name)) {
							break;
						}
						else
						{
							System.out.println("First letter capital required.No special characters allowed");
						}
				}while(true);
				do
				{
					System.out.print("Enter mobile number: ");
					mobNo = sc.next();
					if (service.validatePhoneNumber(mobNo))
					{	
						do
						{
							if(service.checkAccountExisting(mobNo))
							{
								System.out.println("Account already exists");
								System.out.println("Enter mobile number: ");
								mobNo = sc.next();
							}
						}while(service.checkAccountExisting(mobNo));
						break;
					}
					else{
						System.out.println("Mobile number should be numeric and 10 digits staring with 6-9 only");
					}
				}while(true);
				do
				{
					System.out.print("Enter initial amount: ");
					iamt = sc.nextDouble();
					if (service.validateAmount(iamt)) {
						break;
					}
					else
					{
						System.out.println("Amount must be greater than 0");
					}
				}while(true);
				c = new Customer(name, mobNo, iamt);
				if (service.validateAll(c))
					c = service.createAccount(c);
				else
					throw new WalletException("Incorrect Details");
				System.out.println(c);
				System.out.println("Account Created");
				break;

			case 2:
				String mobileNo;
				do
				{
					System.out.print("Enter mobile number: ");
					mobileNo = sc.next();
					if (service.validatePhoneNumber(mobileNo)) {
						do
						{
							if(!service.checkAccountExisting(mobileNo))
							{
								System.out.println("Account does not exist,Please create account first");
								System.out.println("Enter mobile number: ");
								mobileNo= sc.next();
							}
						}while(!service.checkAccountExisting(mobileNo));
						break;
					}
					else
					{
						System.out.println("Mobile number should be numeric and 10 digits staring with 6-9 only");
					}
				}while(true);

				double balance = service.showBalance(mobileNo);
				
				System.out
						.println("Balance for " + mobileNo + " is " + balance);

				break;

			case 3:
				String sMobNo;
				String rMobNo;
				double amount;
				do
				{
					System.out.print("Enter your mobile number: ");
					sMobNo = sc.next();
					if (service.validatePhoneNumber(sMobNo)) {
						do
						{
							if(!service.checkAccountExisting(sMobNo))
							{
								System.out.println("Account does not exist,Please create account first");
								System.out.println("Enter sender's mobile number: ");
								sMobNo = sc.next();
							}
						}while(!service.checkAccountExisting(sMobNo));
							break;
					}
					else
					{
						System.out.println("Mobile number should be numeric and 10 digits staring with 6-9 only");
					}
				}while(true);
				
				do
				{
					System.out.print("Enter receiver's mobile number: ");
					rMobNo = sc.next();	
					if (service.validatePhoneNumber(rMobNo)) {
						do
						{
							if(!service.checkAccountExisting(rMobNo))
							{
								System.out.println("Account does not exist,Please create account first");
								System.out.println("Enter receiver's mobile number: ");
								rMobNo = sc.next();
							}
							
							
						//ADDITIONAL CODE
							if(sMobNo.equals(rMobNo))
							{
								System.out.println("Receiver mobile number cannot be same as sender mobile number");
								System.out.println("Enter receiver's mobile number: ");
								rMobNo = sc.next();
							}
							
						}while(!service.checkAccountExisting(rMobNo));
						break;
					}
					else
					{
						System.out.println("Mobile number should be numeric and 10 digits staring with 6-9 only");
					}
				}while(true);
				
				do
				{
					System.out.println("Amount to be paid: ");
					amount = sc.nextDouble();
					if (service.validateAmount(amount)) {
						break;
					}
					else
						System.out.println("Amount must be greater than 0");
				}
				while(true);
				
				service = new WalletServiceImpl();
				Customer funds = null;
				funds = service.fundTransfer(sMobNo, rMobNo, amount);
				
				
				//ADD
				if(funds==null)
				{
					System.out.println("Amount to be sent cannot be greater than existing balance");
				}
				else
				{
					System.out.println("Payment Done!\nRs." + amount + " sent to "+ rMobNo);
					System.out.println("Your remaining balance is Rs. "
						+ funds.getAmount());
				}

				break;

			case 4:
				String mobNoD;
				double amtD;
				do
				{
					System.out.print("Enter your mobile number: ");
					mobNoD = sc.next();
					if (service.validatePhoneNumber(mobNoD)) {
						do
						{
							if(!service.checkAccountExisting(mobNoD))
							{
								System.out.println("Account does not exist,Please create account first");
								System.out.println("Enter mobile number: ");
								mobNoD = sc.next();
							}
						}while(!service.checkAccountExisting(mobNoD));
						break;
					}
					else
						System.out.println("Mobile number should be numeric and 10 digits staring with 6-9 only");
				}while(true);
				
				do
				{
					System.out.print("Enter amount that is to be deposited: ");
					amtD = sc.nextDouble();
					if (service.validateAmount(amtD)) {
					break;
					}
					else
						System.out.println("Amount must be greater than 0");
				}while(true);

				service = new WalletServiceImpl();
				Customer custD = service.deposit(mobNoD, amtD);

				System.out.println("Your current balance is Rs."
						+ custD.getAmount());

				break;

			case 5:
				String mobNoW;
				double amtW;
				do
				{
					System.out.print("Enter your mobile number: ");
					mobNoW = sc.next();
					if (service.validatePhoneNumber(mobNoW)) {
						do
						{
							if(!service.checkAccountExisting(mobNoW))
							{
								System.out.println("Account does not exist,Please create account first");
								System.out.println("Enter mobile number: ");
								mobNoW = sc.next();
							}
						}while(!service.checkAccountExisting(mobNoW));
						break;
					}
					else
						System.out.println("Mobile number should be numeric and 10 digits staring with 6-9 only");
				}while(true);
				
				do
				{
					System.out.print("Enter amount that to be withdrawn: ");
					amtW = sc.nextDouble();
					if (service.validateAmount(amtW)) {
					break;
					}
					else
						System.out.println("Amount must be greater than 0");
				}while(true);
				
				service = new WalletServiceImpl();
				Customer custW = service.withdraw(mobNoW, amtW);

				System.out.println("Your current balance is Rs. "
						+ custW.getAmount());

				break;

			// case 6:
			//
			// // logic for printing transactions
			// System.out
			// .println("Printing of transactions facility is currently unavailable.");
			// break;
			}

		} while (choice != 6);

		sc.close();
	}

}
